<h1>Search_Scrape</h1>
Search Scrape uses bs4 to scrape google.com for your search queries and give you the basic information you asked for.
<br>
<h2>Usage:</h2>
<pre><code>import SearchScrape as ss
print(ss.scrape("how's the weather"))</code></pre>
